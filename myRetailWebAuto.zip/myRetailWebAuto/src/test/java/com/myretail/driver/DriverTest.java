package com.myretail.driver;

//import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.myretail.utility.ExcelReader;
//import jxl.read.biff.BiffException;

public class DriverTest {
	public static WebDriver driver;
	public static Logger logger=Logger.getLogger(DriverTest.class);
	MyRetailTestCases tc=new MyRetailTestCases();
	public static int i;
  @BeforeTest  
  public void beforeTest() {
	  
	logger.info("Starting execution");
	String browser=System.getProperty("browser");
	logger.info("Browser "+ browser);
	if(browser.equalsIgnoreCase("Firefox")){
		driver=new FirefoxDriver();
	}else if(browser.equalsIgnoreCase("Chrome")){
		String path=System.getProperty("user.dir")+"\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		driver=new ChromeDriver();		
	}
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.get(System.getProperty("url"));
	//Maximise the browser window
	driver.manage().window().maximize();
  }
  @Test
  // Read data from Excel
  public void driver(){
	  String flag;
	  String testCase;
	  logger.info("Inside Driver");
	  Method methods[]=tc.getClass().getDeclaredMethods();
	 
	  try{
		  for(i=1;i<ExcelReader.getRowCount();i++)
		  {
			  
			  logger.info("row  "+ i);
			 flag = ExcelReader.getCellValue(1, i);
			 String result="fail";
			 
			 if(flag.equalsIgnoreCase("Y")){
				 testCase = ExcelReader.getCellValue(2, i);
				 logger.info("Test case to execute "+ testCase);
				 for(Method method:methods){
					 if(method.getName().equalsIgnoreCase(testCase)){
						result= (String) method.invoke(tc);
						//Write result to excel file
						 logger.info("Writing result");
						 ExcelReader.writeResult(3, i, result);
					 }
				 }
			 }
		  }
		  
	  }catch(Exception e){
		  System.out.println(e.getMessage());
		 logger.info("In the catch"); 
	  }//Close browser instance and Excel cleanup
	  finally{
		  logger.info("Cleanup");
		  driver.close();
		  driver.quit();
		  ExcelReader.cleanupExcel();
		  
	  }
	  
  }
  
//  @AfterTest
//  public void afterTest() {
//	  logger.info("Cleanup");
//	  driver.close();
//	  driver.quit();	  
//  }

}
