package com.myretail.driver;

//import java.io.FileNotFoundException;
//import java.io.IOException;
//import org.apache.log4j.Logger;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.myretail.driver.DriverTest;
import com.myretail.utility.ExcelReader;
//import com.myretail.page.HomePage;
import com.myretail.utility.WebConnector;

public class MyRetailTestCases {

	public String testFindAllProducts(){
		DriverTest.logger.info("Inside Find All Product");
		//WebDriver driver.findElement(By.tagName("title")).getTitle();
		try{
			//click on the findAllProducts button
			WebConnector.click("findAllProducts");
			//verify the results
			Assert.assertTrue(WebConnector.verifyRowCount("productDetails", ExcelReader.getCellValue(5, DriverTest.i)));
			return "pass";
		}catch(Throwable t){
			DriverTest.logger.info("Inside tc catch");
			DriverTest.logger.info(t.getMessage());
			return "fail";
		}	
	}
	
	public String testFindProductsInStock(){
		try{
			//click on the findAllProducts button
			WebConnector.click("findAllProductsinStock");
			
			//verify the results
			Assert.assertTrue(WebConnector.verifyRowCount("productDetails", ExcelReader.getCellValue(5, DriverTest.i)));
			return "pass";
		}catch(Throwable t){
			DriverTest.logger.info(t.getMessage());
			return "fail";
		}	
	}
	public String testFindProductsOutOfStock(){
		try{
			//click on the findAllProducts button
			WebConnector.click("findAllProductsoutofStock");
			
			//verify the results
			Assert.assertTrue(WebConnector.verifyRowCount("productDetails", ExcelReader.getCellValue(5, DriverTest.i)));
			return "pass";
		}catch(Throwable t){
			DriverTest.logger.info(t.getMessage());
			return "fail";
		}	
	}
	
	public String testSearchById(){
		
		try{
			WebConnector.sendKeys("productId",ExcelReader.getCellValue(4, DriverTest.i));
			WebConnector.click("search");
			//verify the results
			Assert.assertTrue(WebConnector.verifyRowCount("productDetails", ExcelReader.getCellValue(5, DriverTest.i)));
			return "pass";
		}catch(Throwable e){
			DriverTest.logger.info(e.getMessage());
			return "fail";
		}	
	}
	public String testBlankSearch(){
		DriverTest.logger.info("Inside Blank search");
	   try{
		WebConnector.clear("productId");
		WebConnector.click("search");
		//verify the results
		Assert.assertTrue(WebConnector.verifyText("No product id entered to search!!!"));
		return "pass";
	}catch(Throwable t){
		DriverTest.logger.info(t.getMessage());
		return "fail";
	}	
   }

}
