package com.myretail.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class DataReader {
	
	private static Properties prop=null;
	
	//Returns property value of the given key
	public static String getData(String key) throws FileNotFoundException, IOException{
		if(prop == null){
			prop = new Properties();
			String path=System.getProperty("user.dir")+"\\src\\test\\resources\\objectrepo.properties";

			prop.load(new FileInputStream(path));
		}
		return prop.getProperty(key);	
	}
}
