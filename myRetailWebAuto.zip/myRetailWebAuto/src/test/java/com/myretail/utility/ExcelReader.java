package com.myretail.utility;

import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
//import org.apache.log4j.Logger;
import com.myretail.driver.DriverTest;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
//import jxl.write.WriteException;
//import jxl.write.biff.RowsExceededException;

public class ExcelReader {
	
	static FileInputStream fis;
	static FileOutputStream fos;
	static Workbook workbook = null;
	static Sheet sheet = null;
	
	
	public static String getPath(){
		String path= System.getProperty("user.dir")+"\\Data\\myretail.xls";
		DriverTest.logger.info("Excel path "+ path);
		return path;
	}
	
	public static Sheet getSheet() throws BiffException, IOException{
		if(sheet == null){
			fis=new FileInputStream(getPath());
			workbook=Workbook.getWorkbook(fis);
			sheet=workbook.getSheet(0);
		}
		return sheet;
	}
	
	public static int getRowCount() throws BiffException, IOException{
		return getSheet().getRows();
	}
	
	public static String getCellValue(int col, int row) throws BiffException, IOException{
		return getSheet().getCell(col, row).getContents();
	}
	
	public static void cleanupExcel(){
		if(workbook!=null){
			workbook.close();
			workbook=null;
			sheet=null;
		}
		
	}
	
	public static void writeResult(int col, int row, String result) throws Exception{
		
		File f=new File(getPath());
		Workbook wb= Workbook.getWorkbook(f);
		WritableWorkbook wwb = Workbook.createWorkbook(f, wb);
		WritableSheet ws= wwb.getSheet(0);
		Label l = new Label(col, row, result);
		DriverTest.logger.info("row "+ row);
		DriverTest.logger.info("col "+ col);
		DriverTest.logger.info("result "+ result);
		ws.addCell(l);
		wwb.write();
		wwb.close();
		
		
	}

}
