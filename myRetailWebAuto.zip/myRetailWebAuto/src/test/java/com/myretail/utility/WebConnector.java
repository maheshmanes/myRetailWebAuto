package com.myretail.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.openqa.selenium.By;
//import org.openqa.selenium.WebElement;
import com.myretail.driver.DriverTest;
//import junit.framework.Assert;


public class WebConnector {
	public static boolean verifyRowCount(String webTable,String expectedRows){
		int expRows= Integer.parseInt(expectedRows);
		int actualRows = DriverTest.driver.findElements(By.tagName("tr")).size()-1;
		System.out.println("actual Rows "+ actualRows);
		if(actualRows == expRows){
			return true;
		}else{
			return false;
		}
	}
	
	public static void click(String object) throws FileNotFoundException, IOException{
		DriverTest.driver.findElement(By.id(DataReader.getData(object))).click();
	}
	
	public static void sendKeys(String object, String value) throws FileNotFoundException, IOException{
		DriverTest.driver.findElement(By.id(DataReader.getData(object))).sendKeys(value);
	}
	
//	@SuppressWarnings("deprecation")
	public static boolean verifyText(String expText){
		DriverTest.logger.info(DriverTest.driver.getPageSource().contains(expText));
		return DriverTest.driver.getPageSource().contains(expText);
	}
	
	public static void clear(String object) throws FileNotFoundException, IOException{
		DriverTest.driver.findElement(By.id(DataReader.getData(object))).clear();
	}

}
